# ============================================================
# FluxBridge Python Client (File-IPC edition)
# ============================================================
import json
import time
import os
import threading
from dataclasses import dataclass

MOD_DIR  = r"D:\steam\steamapps\common\Subnautica2\Subnautica2\Binaries\Win64\ue4ss\Mods\FluxBridge\Scripts"
IN_FILE  = os.path.join(MOD_DIR, "bridge_in.json")
OUT_FILE = os.path.join(MOD_DIR, "bridge_out.json")

@dataclass
class GameState:
    pos_x: float = 0.0
    pos_y: float = 0.0
    pos_z: float = 0.0
    oxygen: float = 0.0
    max_oxygen: float = 0.0
    last_update: float = 0.0

class FluxBridge:
    def __init__(self):
        self.state = GameState()
        self._lock = threading.Lock()
        self._running = False
        self._req_id = 0
        self._last_mtime = 0
        self._pending = {}

    def start(self):
        self._running = True
        threading.Thread(target=self._recv_loop, daemon=True).start()
        print(f"[FluxBridge] Watching {OUT_FILE}")

    def stop(self):
        self._running = False

    def _recv_loop(self):
        while self._running:
            try:
                if os.path.exists(OUT_FILE):
                    mtime = os.path.getmtime(OUT_FILE)
                    if mtime > self._last_mtime:
                        self._last_mtime = mtime
                        with open(OUT_FILE, "r", encoding="utf-8") as f:
                            raw = f.read().strip()
                        if raw:
                            try:
                                msg = json.loads(raw)
                                self._handle(msg)
                            except json.JSONDecodeError:
                                pass
            except OSError:
                pass
            time.sleep(0.03)

    def _handle(self, msg):
        req_id = msg.get("id")
        if req_id and req_id in self._pending:
            cb = self._pending.pop(req_id)
            cb(msg)
            return
        with self._lock:
            if "pos" in msg:
                p = msg["pos"]
                self.state.pos_x = p.get("x", 0)
                self.state.pos_y = p.get("y", 0)
                self.state.pos_z = p.get("z", 0)
            if "oxygen" in msg:
                self.state.oxygen     = msg["oxygen"]
                self.state.max_oxygen = msg.get("maxOxygen", 0)
            self.state.last_update = time.time()

    def _send(self, payload, callback=None):
        self._req_id += 1
        payload["id"] = self._req_id
        raw = json.dumps(payload, separators=(",", ":"))
        with open(IN_FILE, "w", encoding="utf-8") as f:
            f.write(raw)
        if callback:
            self._pending[self._req_id] = callback
        return self._req_id

    # ---------- Публичное API ----------
    def add_item(self, name: str, amount: int, callback=None):
        return self._send({"action": "SET_ITEM_COUNT", "item": name, "value": amount},
                          callback)

    def get_status(self, callback=None):
        return self._send({"action": "GET_TELEMETRY"}, callback)

    def ping(self, callback=None):
        return self._send({"action": "PING"}, callback)

    def snapshot(self) -> GameState:
        with self._lock:
            return GameState(**vars(self.state))


# ============================================================
# Пример
# ============================================================
if __name__ == "__main__":
    b = FluxBridge()
    b.start()
    time.sleep(1)

    b.ping(lambda r: print(f"PING -> {r}"))
    time.sleep(0.5)

    # Попробуем выдать воду
    b.add_item("Water", 5, lambda r: print(f"SET  -> {r}"))
    time.sleep(0.5)

    b.get_status(lambda r: print(f"TELE -> {r}"))
    time.sleep(0.5)

    s = b.snapshot()
    print(f"Pos: ({s.pos_x:.1f}, {s.pos_y:.1f}, {s.pos_z:.1f})")
    print(f"Oxygen: {s.oxygen:.1f} / {s.max_oxygen:.1f}")

    b.stop()