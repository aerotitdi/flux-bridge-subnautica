import time
from flux_client import FluxBridge

b = FluxBridge()
b.start()
time.sleep(1)

print("--- PING ---")
b.ping(lambda r: print("PING ->", r))
time.sleep(0.5)

print("--- SET Water ---")
b.add_item("Water", 5, lambda r: print("SET  ->", r))
time.sleep(0.5)

print("--- TELEMETRY ---")
b.get_status(lambda r: print("TELE ->", r))
time.sleep(0.5)

b.stop()
print("--- DONE ---")