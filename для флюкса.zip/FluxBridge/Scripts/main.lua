-- ============================================================
-- FluxBridge v2.0 (S2ML Bridge Edition)
-- UE4SS Lua mod for Subnautica 2 (UE 5.6)
-- Использует S2ML для безопасной работы с игрой.
-- ============================================================

-- 1. Подключение S2ML
local ok, S2 = pcall(require, "S2MLBridge")
if not ok then
    print("[FluxBridge] КРИТИЧЕСКАЯ ОШИБКА: Не удалось загрузить S2MLBridge.")
    print("[FluxBridge] Убедитесь, что S2ML установлен и включён в mods.txt.")
    return
end

-- Проверка версии (рекомендуется)
S2.RequireVersion("3.1.0")

-- 2. Константы
local MOD_DIR  = "ue4ss\\Mods\\FluxBridge\\Scripts\\"
local IN_FILE  = MOD_DIR .. "bridge_in.json"
local OUT_FILE = MOD_DIR .. "bridge_out.json"
local POLL_MS  = 50

-- 3. Вспомогательные функции (JSON, файлы) остаются без изменений
local function EncodeJSON(t)
    local function esc(s) return '"' .. tostring(s):gsub('\\','\\\\'):gsub('"','\\"'):gsub('\n','\\n') .. '"' end
    local function enc(v)
        local vt = type(v)
        if vt == "nil" then return "null"
        elseif vt == "boolean" then return tostring(v)
        elseif vt == "number" then return tostring(v)
        elseif vt == "string" then return esc(v)
        elseif vt == "table" then
            if #v > 0 then
                local p = {}
                for _, x in ipairs(v) do p[#p+1] = enc(x) end
                return "[" .. table.concat(p, ",") .. "]"
            else
                local p = {}
                for k, x in pairs(v) do p[#p+1] = esc(k) .. ":" .. enc(x) end
                return "{" .. table.concat(p, ",") .. "}"
            end
        end
        return "null"
    end
    return enc(t)
end

local function ParseJSON(str)
    if not str or str == "" then return nil end
    local t = {}
    for k, v in string.gmatch(str, '"([%w_]+)%s*:%s*"([^"]*)"') do t[k] = v end
    for k, v in string.gmatch(str, '"([%w_]+)%s*:%s*(%-?%d+%.?%d*)') do t[k] = tonumber(v) end
    for k in string.gmatch(str, '"([%w_]+)%s*:%s*true')  do t[k] = true  end
    for k in string.gmatch(str, '"([%w_]+)%s*:%s*false') do t[k] = false end
    if next(t) then return t end
    return nil
end

local function ReadInFile()
    local f = io.open(IN_FILE, "r"); if not f then return nil end
    local c = f:read("*a"); f:close()
    local g = io.open(IN_FILE, "w"); if g then g:write(""); g:close() end
    return c
end

local function WriteOutFile(str)
    local f = io.open(OUT_FILE, "w"); if f then f:write(str); f:close() end
end

-- 4. Обработка команд через S2ML
local function ProcessCommand(cmd)
    local id = cmd.id or 0
    local action = cmd.action

    if action == "SET_ITEM_COUNT" then
        -- Используем S2ML для добавления предмета
        local item_name = cmd.item
        local count = cmd.value
        local success, err = pcall(function()
            S2.Inventory.Give(item_name, count)
        end)
        if success then
            return { id = id, status = "ok", message = "OK (via S2ML)" }
        else
            return { id = id, status = "error", message = "S2ML error: " .. tostring(err) }
        end

    elseif action == "GET_TELEMETRY" then
        local result = { id = id, status = "ok" }
        -- Получаем игрока через S2ML
        local PC = S2.Player.GetPlayerController()
        if PC and PC.Pawn and PC.Pawn:IsValid() then
            local pawn = PC.Pawn
            -- Позиция
            local loc = pawn:K2_GetActorLocation()
            if loc then
                result.pos = { x = loc.X, y = loc.Y, z = loc.Z }
            end
            -- Кислород: используем S2ML для доступа к атрибутам
            -- (Предполагаем, что S2ML предоставляет удобный доступ, например, через PlayerState или AttributeSet)
            -- Если нет, можно найти вручную, но это менее надёжно.
            -- Для примера, попробуем через S2.Player.GetAttribute
            local oxygen = S2.Player.GetAttribute(pawn, "Oxygen")
            local maxOxygen = S2.Player.GetAttribute(pawn, "MaxOxygen")
            if oxygen then result.oxygen = oxygen end
            if maxOxygen then result.maxOxygen = maxOxygen end
        end
        return result

    elseif action == "PING" then
        return { id = id, status = "ok", message = "pong" }
    end

    return { id = id, status = "error", message = "Unknown action" }
end

-- 5. Основной цикл
local function MainLoop()
    local raw = ReadInFile()
    if raw and #raw > 0 then
        local cmd = ParseJSON(raw)
        if cmd then
            -- Выполняем команду в игровом потоке
            ExecuteInGameThread(function()
                local resp = ProcessCommand(cmd)
                WriteOutFile(EncodeJSON(resp))
            end)
        end
    end
    -- Планируем следующий вызов
    ExecuteWithDelay(POLL_MS, MainLoop)
end

-- 6. Инициализация
do
    local f = io.open(IN_FILE, "w"); if f then f:write(""); f:close() end
    local g = io.open(OUT_FILE, "w"); if g then g:write(""); g:close() end
end

-- Запускаем цикл после загрузки S2ML
S2.Player.WhenReady(function(PC)
    print("[FluxBridge] S2ML готов, игрок найден. Запуск основного цикла.")
    MainLoop()
end)

print("[FluxBridge] Ожидание готовности S2ML...")