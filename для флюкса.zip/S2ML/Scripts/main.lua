﻿-- main.lua
require("S2ML_Core")
require("S2ML_Events")
require("S2ML_Inventory")
S2ML.Init()
S2ML.Log("Modding Toolkit successfully injected and ready for dependent mods.")
