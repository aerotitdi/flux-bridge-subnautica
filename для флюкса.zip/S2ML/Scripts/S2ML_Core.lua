﻿-- S2ML_Core.lua
S2ML = S2ML or {}
S2ML.Version = "1.0.0"
S2ML.DebugMode = true
function S2ML.Log(message, level)
    level = level or "INFO"
    if level == "DEBUG" and not S2ML.DebugMode then return end
    print(string.format("[S2ML:%s] %s", level, message))
end
function S2ML.Init()
    S2ML.Log("Initializing Subnautica 2 Modding Library v" .. S2ML.Version)
end
