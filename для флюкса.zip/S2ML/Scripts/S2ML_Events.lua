﻿-- S2ML_Events.lua
S2ML.Events = S2ML.Events or {}
S2ML.Events.Listeners = {}
function S2ML.Events.Subscribe(EventName, Callback)
    if not S2ML.Events.Listeners[EventName] then
        S2ML.Events.Listeners[EventName] = {}
    end
    table.insert(S2ML.Events.Listeners[EventName], Callback)
    S2ML.Log("Subscribed to event: " .. EventName, "DEBUG")
end
function S2ML.Events.Trigger(EventName, ...)
    if S2ML.Events.Listeners[EventName] then
        for _, callback in ipairs(S2ML.Events.Listeners[EventName]) do
            pcall(callback, ...)
        end
    end
end
RegisterHook("/Script/Engine.PlayerController:ClientRestart", function(Context, NewPawn)
    local PC = Context:get()
    S2ML.Events.Trigger("OnPlayerSpawned", PC)
end)
RegisterHook("/Script/Subnautica2.CraftingStation:OnInteract", function(Context, Player)
    S2ML.Events.Trigger("OnFabricatorOpened", Context:get(), Player:get())
end)
