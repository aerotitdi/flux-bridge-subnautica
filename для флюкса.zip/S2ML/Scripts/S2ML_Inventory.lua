﻿-- S2ML_Inventory.lua
S2ML.Inventory = S2ML.Inventory or {}
function S2ML.Inventory.GetBaseContainers(PlayerLocation, Radius)
    local containers = {}
    local allActors = FindAllOf("StorageContainer")
    for _, actor in pairs(allActors) do
        if actor and actor:IsValid() then
            local dist = actor:GetDistanceTo(PlayerLocation)
            if dist <= Radius then
                table.insert(containers, actor)
            end
        end
    end
    return containers
end
function S2ML.Inventory.GetItemCount(ContainerActor, ItemID)
    if not ContainerActor or not ContainerActor.InventoryComponent then return 0 end
    return ContainerActor.InventoryComponent:K2_GetItemQuantity(ItemID)
end
function S2ML.Inventory.ConsumeItem(ContainerActor, ItemID, Amount)
    if not ContainerActor or not ContainerActor.InventoryComponent then return false end
    return ContainerActor.InventoryComponent:K2_ConsumeItem(ItemID, Amount)
end
